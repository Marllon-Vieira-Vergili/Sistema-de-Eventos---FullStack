package com.marllon.vieira.vergili.eventos.gerenciamento_eventos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GerenciamentoDeEventosApplicationTests {

	@Test
	void contextLoads() {
	}

}
