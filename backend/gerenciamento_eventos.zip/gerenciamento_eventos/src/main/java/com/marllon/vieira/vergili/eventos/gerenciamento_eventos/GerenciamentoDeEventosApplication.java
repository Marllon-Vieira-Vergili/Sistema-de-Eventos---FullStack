package com.marllon.vieira.vergili.eventos.gerenciamento_eventos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GerenciamentoDeEventosApplication {

	public static void main(String[] args) {
		SpringApplication.run(GerenciamentoDeEventosApplication.class, args);
	}

}
